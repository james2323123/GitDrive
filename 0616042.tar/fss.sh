#!/bin/sh
ls -lFAR| sort -k 5 -n -r | awk \
	'BEGIN {totalsize=0;filecount=0;dircount=0;count=0} \
	/^[-d]/ {count++;if(count<=5)print count": "$5" "$9 } \
	/^-/ {filecount++;totalsize+=$5} \
	/^d/{dircount++} \
	END{print "file num: "filecount;\
	print"dir count: "dircount;\
	print"total size: "totalsize;\
}'
