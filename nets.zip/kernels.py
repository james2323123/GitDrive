import torch
import math
import random

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# 計算任兩點的歐氏距離 (weight matrix)
def euclidean_matrix(Q, K):
    return torch.sqrt(
    torch.sum(Q ** 2, dim=-1).unsqueeze(-1)
    +torch.sum(K ** 2, dim=-1).unsqueeze(-2)
    -2*torch.matmul(Q, K.transpose(-2, -1))
    )

# normalize方法，其實就是把資料映射到 [a,b] ，公式則是參考 wiki
# https://en.wikipedia.org/wiki/Normalization_(statistics)
def normalize(G, a=-9, b=9):
    max_vals = torch.max(torch.max(G, dim=-1)[0], dim=-1)[0]
    min_vals = torch.min(torch.min(G, dim=-1)[0], dim=-1)[0]
    return a + ((G - min_vals[..., None, None]) * (b - a) / (max_vals - min_vals)[..., None, None])

def cauchy(Q, K):
    # 計算 ||x - y||
    dist = euclidean_matrix(Q,K)
    # 計算 1 / (1 + (||x - y||/sigma)^ 2)
    compatibility = 1 / (1 + dist.pow(2))
    return compatibility

def normalized_cauchy(Q, K, a=-9, b=9):
    # 計算 ||x - y||
    dist = euclidean_matrix(Q,K)
    # 計算 1 / (1 + (||x - y||/sigma)^ 2)
    compatibility = 1 / (1 + dist.pow(2))
    return normalize(compatibility, a, b)

def clipped_cauchy(Q, K, a=9):
    # 計算 ||x - y||
    dist = euclidean_matrix(Q,K)
    # 計算 1 / (1 + (||x - y||/sigma)^ 2)
    compatibility = 1 / (1 + dist.pow(2))
    return torch.clamp(compatibility,-a,a)

def nystrom_cauchy(Q, K, m=2):
    idxs = torch.tensor(random.sample(range(Q.shape[-2]), min(m, Q.shape[-2]))).cuda()
    F = euclidean_matrix(Q, torch.index_select(K, -2, idxs))
    A = euclidean_matrix(torch.index_select(Q, -2, idxs), torch.index_select(K, -2, idxs))
    B = euclidean_matrix(torch.index_select(Q, -2, idxs), K)
    dist = torch.matmul(F, torch.linalg.lstsq(A, B).solution)
    return 1 / (1 + dist.pow(2))

def nystrom_cauchy_one_landmark(Q, K):
    idx = torch.tensor(random.randint(0, Q.shape[-2]-1)).cuda()
    F = euclidean_matrix(Q, torch.index_select(K, -2, idx))
    A = euclidean_matrix(torch.index_select(Q, -2, idx), torch.index_select(K, -2, idx))
    B = euclidean_matrix(torch.index_select(Q, -2, idx), K)
    # even though this is technically the same as (F @ B) / A, this somehow uses less memory
    dist = torch.matmul(F, torch.linalg.lstsq(A, B).solution)
    return 1 / (1 + dist.pow(2))

def nystrom_cauchy_one_landmark_no_random(Q, K):
    F = euclidean_matrix(Q, torch.narrow(K, -2, 0, 1))
    A = euclidean_matrix(torch.narrow(Q, -2, 0, 1), torch.narrow(K, -2, 0, 1))
    B = euclidean_matrix(torch.narrow(Q, -2, 0, 1), K)
    dist = torch.matmul(F, torch.linalg.lstsq(A, B).solution)
    return 1 / (1 + dist.pow(2))

def nystrom_cauchy_one_landmark_no_random_normalized(Q, K, a=-9, b=9):
    F = euclidean_matrix(Q, torch.narrow(K, -2, 0, 1))
    A = euclidean_matrix(torch.narrow(Q, -2, 0, 1), torch.narrow(K, -2, 0, 1))
    B = euclidean_matrix(torch.narrow(Q, -2, 0, 1), K)
    dist = torch.matmul(F, torch.linalg.lstsq(A, B).solution)
    return normalize(1 / (1 + dist.pow(2)), a, b)